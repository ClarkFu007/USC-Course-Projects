# EE569 Homework Assignment #5: Competition
# Date: May 3, 2020
# Name: Yao Fu
# USC ID: 6786354176
# email: yaof@usc.edu
#
# Software: Python 3.6
# Operating System: Windows 10
========================================================================
    CONSOLE APPLICATION : [EE569_hw5_competition_6786354176_Yao Fu] Project Overview
========================================================================

This file contains a summary of what I will find in each of the files that
make up my [EE569_hw5_competition_6786354176_Yao Fu] application.

Steps:

1. Open "EE569_hw5_competition_6786354176_Yao_Fu.py".
	This is the main part for the project.


2. Run the section "def main()".
	This is the main program for the algorithms in problem 1.
     
   Step1: You need to import training data, training labels, testing data, and testing labels.	
          The important statements are
                                      "(TrainData, TrainLabel), (TestData, TestLabel) = cifar10.load_data()"

   Step2: Running the function "net_accuracy_demo(train_data, train_label, test_data, test_label,
                                      ini_name, i, learning_rate, decay_value)".


   Step3: The function "def creat_net(train_data, class_num, ini_name)" is to build the convolutional neural network 
derived from the VGG16.


3. Run the program and follow the instructions and finally you will get performance curves. 
  

/////////////////////////////////////////////////////////////////////////////
Other notes:

   I guarantee you that in my computer I can see all the pictures in my report and plot required figures.
If you cannot run my program successfully, please let me know and I will come to your office to show you.
   
   Thank you very much!

Sincerely,
Yao Fu

/////////////////////////////////////////////////////////////////////////////

